window.addEventListener('DOMContentLoaded', () => {
    // Initialize Animate On Scroll (AOS)
    // This provides the automated visual effects the user requested
    AOS.init({
        duration: 1000,
        easing: 'ease-in-out',
        once: true,
        mirror: false
    });

    // Number Counter Animation
    const counters = document.querySelectorAll('.counter');
    const speed = 200;

    const animateCounters = () => {
        counters.forEach(counter => {
            // Get the target once at the start of animation
            const targetText = counter.innerText;
            const target = +targetText.replace(/[^\d.]/g, '');
            const suffix = targetText.match(/[^\d.]+/) || '';
            let count = 0;

            const updateCount = () => {
                const inc = target / speed;
                if (count < target) {
                    count += inc;
                    counter.innerText = Math.ceil(count) + suffix;
                    setTimeout(updateCount, 1);
                } else {
                    counter.innerText = target + suffix;
                }
            };
            updateCount();
        });
    };

    // Trigger counters when impact section is reached
    const impactSection = document.querySelector('.impact');
    const observer = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting) {
            animateCounters();
            observer.unobserve(impactSection);
        }
    }, { threshold: 0.5 });

    if (impactSection) {
        observer.observe(impactSection);
    }

    // Hide loader and animate logo image
    const loader = document.querySelector('.loader-wrapper');
    const animLogo = document.getElementById('animated-logo');

    if (loader) {
        // Step 1: Fade in the logo image inside the loader
        if (animLogo) {
            setTimeout(() => {
                animLogo.style.opacity = '1';
                animLogo.style.transform = 'scale(1)';
            }, 500);
        }

        // Step 2: Hide loader after animation completion
        setTimeout(() => {
            loader.classList.add('fade-out');
            document.body.style.overflow = 'auto';
        }, 5000);
    }
});
