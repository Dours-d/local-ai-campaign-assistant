/**
 * Language Toggle System
 * Supports Arabic (ar) and English (en)
 * Stores preference in localStorage
 */

const i18n = {
    currentLang: localStorage.getItem('lang') || 'en',

    translations: {
        en: {
            // Navigation
            nav_mission: 'Amanah',
            nav_impact: 'Shahada',
            nav_campaigns: 'The Field',
            nav_contact: 'Direct Line',
            nav_donate: 'Bear Witness',

            // Hero
            hero_title: 'The Clarity of [Truth]<br>The Service of [Amanah]',
            hero_subtitle: 'Fajr is the quiet fulfillment of a collective trust. Rooted in the humble resilience of the olive tree, we stand with our families in Gaza to provide direct, independent support.',
            hero_cta: 'SERVE THE AMANAH',
            hero_secondary: 'The Logic',

            // Impact section (Shahada)
            impact_title: 'The Evidence of Truth',
            impact_communities: 'Days of Direct Witness',
            impact_projects: 'EUR Batch Honesty',
            impact_lives: '% Corporate Friction Bypassed',
            impact_transparency: 'Recorded Proofs of Truth',

            // About section
            about_title: 'Trust in Action',
            about_text: 'Fajr.today is a free service for all—an independent bridge for the fulfillment of trust, not a financial institution. We enable any humble steward to manage resources through an AI-assisted system of clarity. Our purpose is the better condition of families today and a future of dignity on the Land of their Grand-parents, preserving the sacred nature of the Amanah without the vocation of a bank.',
            about_cta: 'Our Ledger',

            // Campaigns section
            campaigns_title: 'Paths of Goodness',
            campaign_monthly_title: 'Constant Care',
            campaign_monthly_desc: 'Provide steady, reliable support to our families through regular commitments.',
            campaign_monthly_cta: 'COMMIT MONTHLY',
            campaign_once_title: 'Urgent Relief',
            campaign_once_desc: 'Immediate assistance for the most pressing humanitarian needs on the ground.',
            campaign_once_cta: 'GIVE NOW',
            campaign_resilience_title: 'Community Fund',
            campaign_resilience_desc: 'Supporting long-term reconstruction and dignity for a life beyond the siege.',
            campaign_resilience_cta: 'VIEW THE FIELD',

            // Footer
            footer_rights: '© 2026 Fajr.today | Fulfilling the Trust with Clarity.',

            // Toggle
            lang_toggle: 'عربي'
        },
        ar: {
            // Navigation
            nav_mission: 'الأمانة',
            nav_impact: 'الشهادة',
            nav_campaigns: 'الميدان',
            nav_contact: 'الخط المباشر',
            nav_donate: 'كن شاهداً',

            // Hero
            hero_title: 'وضوح [الحقيقة]<br>خدمة [الأمانة]',
            hero_subtitle: 'الفجر هو الأداء الهادئ لأمانة جماعية. متجذرون في الصمود المتواضع لشجرة الزيتون، نقف مع أهلنا في غزة لتقديم دعم مباشر ومستقل.',
            hero_cta: 'أدِّ الأمانة الآن',
            hero_secondary: 'منطقنا',

            // Impact section (Shahada)
            impact_title: 'أدلة الحقيقة',
            impact_communities: 'يوماً من الشهادة المباشرة',
            impact_projects: 'يورو - صدق التجميع',
            impact_lives: '% احتكاك مؤسسي (تم تفاديه)',
            impact_transparency: 'شهادات حقيقة مسجلة',

            // About section
            about_title: 'الثقة في العمل',
            about_text: 'فجر.اليوم هو خدمة مجانية للجميع - جسر مستقل لأداء الأمانة، وليس مؤسسة مالية. نحن نمكّن أي مؤتمن متواضع من إدارة الموارد من خلال نظام وضوح مدعوم بالذكاء الاصطناعي. غرضنا هو تحسين أحوال العائلات اليوم ومستقبل من الكرامة على أرض أجدادهم، مع الحفاظ على الطبيعة المقدسة للأمانة دون أي صفة مصرفية.',
            about_cta: 'سجلنا',

            // Campaigns section
            campaigns_title: 'دروب الخير',
            campaign_monthly_title: 'رعاية مستمرة',
            campaign_monthly_desc: 'قدم دعماً ثابتاً وموثوقاً لعائلاتنا من خلال التزامات منتظمة.',
            campaign_monthly_cta: 'التزم شهرياً',
            campaign_once_title: 'إغاثة عاجلة',
            campaign_once_desc: 'مساعدة فورية للاحتياجات الإنسانية الأكثر إلحاحاً على أرض الواقع.',
            campaign_once_cta: 'تبرع الآن',
            campaign_resilience_title: 'صندوق المجتمع',
            campaign_resilience_desc: 'دعم إعادة الإعمار على المدى الطويل والكرامة لحياة ما بعد الحصار.',
            campaign_resilience_cta: 'عرض الميدان',

            // Footer
            footer_rights: '© ٢٠٢٦ فجر.اليوم | أداء الأمانة بكل وضوح.',

            // Toggle
            lang_toggle: 'English'
        }
    },

    t(key) {
        return this.translations[this.currentLang][key] || key;
    },

    setLang(lang) {
        this.currentLang = lang;
        localStorage.setItem('lang', lang);
        document.documentElement.lang = lang;
        document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
        this.updatePage();
    },

    toggle() {
        this.setLang(this.currentLang === 'en' ? 'ar' : 'en');
    },

    updatePage() {
        // Update all elements with data-i18n attribute
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            el.innerHTML = this.t(key);
        });

        // Update toggle button text
        const toggleBtn = document.getElementById('lang-toggle');
        if (toggleBtn) {
            toggleBtn.textContent = this.t('lang_toggle');
        }
    },

    init() {
        document.documentElement.lang = this.currentLang;
        document.documentElement.dir = this.currentLang === 'ar' ? 'rtl' : 'ltr';
        this.updatePage();
    }
};

// Initialize on DOM load
window.addEventListener('DOMContentLoaded', () => {
    i18n.init();
});
