# local_ai_campaign_assistant
a local system to emulate pipelines of campaign creation on fundraising sites

processus core

```
[WhatsApp Form Collector] → [DeskAgent v1 Desktop] → [Whydonate Bot] → [Monitoring Dashboard]
```
